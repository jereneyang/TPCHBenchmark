import os
import json

lineitemIntIdx = 4
lineitemFloatIdx = 7
lineitemQuanityIdx = 4

orderIntIdx = 1
orderFloatIdx = 3

customerMktsegmentIdx = 6
orderDateIdx = 4

lineitemShipDateIdx = 10

delim = '|'
from azure.storage.blob import BlockBlobService
bbs = BlockBlobService(account_name='xcalardatawarehouse', account_key='GjsUEJc1yD5XMIWxiUlxbet/DkKB6/kpTrhxm3hGwbZ8XXKEiQ5bBL/rKoBFtNpadtgJgbeejNFhgiR3awGU3Q==')

def file_load(inp, ins):
    inObj = json.loads(ins.read())
    numFiles = inObj["numRows"]
    startFile = inObj["startRow"]

    for ii in xrange(startFile, startFile + numFiles):
        for record in q18_line_order_load(ii):
            yield record

def q18_line_order_load(num):
    ins = bbs.get_blob_to_bytes("tpch-sf100-tmp", "lineitem/lineitem_" + str(num) + ".csv").content
    order = bbs.get_blob_to_bytes("tpch-sf100-tmp", "orders/order_" + str(num) + ".csv").content
    delim = '|'
    # header
    orderLines = order.split("\n")
    orderHeader = orderLines[0][:-1].split(delim)
    orderVals = orderLines[1][:-1].split(delim)
    orderLineId = 2
    hasHeader = True
    lineitemHeader = None
    prevOrderNum = int(orderVals[0])
    orderGroup = []
    quantitySum = 0
    for line in ins.split("\n"):
        if len(line) == 0:
            continue
        if hasHeader:
            lineitemHeader = line.split(delim)
            hasHeader = False
            continue
        record = {}
        lineVals = line.split(delim)
        orderNum = int(lineVals[0])
        if orderNum != prevOrderNum:
            # new order group, yield the previous group with quanity sums
            if quantitySum > 300:
                for record in orderGroup:
                    record["L_QUANITY_SUM"] = int(quantitySum)
                    yield record
            # start new order group
            orderVals = orderLines[orderLineId][:-1].split(delim)
            orderLineId += 1
            prevOrderNum = orderNum
            orderGroup = []
            quantitySum = 0
        for i in xrange(len(lineitemHeader)):
            record[lineitemHeader[i]] = lineVals[i]
            # sum up quantities
            if i == 4:
                quantitySum += int(record[lineitemHeader[i]])
        for i in xrange(len(orderHeader)):
            record[orderHeader[i]] = orderVals[i]
        orderGroup.append(record)
    # yield final orderGroup
    if quantitySum > 300:
        for record in orderGroup:
            record["L_QUANITY_SUM"] = int(quantitySum)
            yield record

def lineitem_group(inp, ins):
    hasHeader = True
    lineitemHeader = None
    prevOrderNum = None

    orderGroup = []
    quantitySum = 0

    for line in ins:
        if hasHeader:
            lineitemHeader = line[:-1].split(delim)
            hasHeader = False
            continue

        record = {}
        lineVals = line[:-1].split(delim)

        orderNum = int(lineVals[0])
        if prevOrderNum == None:
            prevOrderNum = orderNum

        if orderNum != prevOrderNum:
            # new order group, yield the previous group with quanity sums
            if quantitySum > 300:
                for record in orderGroup:
                    record["L_QUANITY_SUM"] = int(quantitySum)
                    yield record

            # start new order group
            prevOrderNum = orderNum

            orderGroup = []
            quantitySum = 0

        for i in xrange(len(lineitemHeader)):
            if i <= lineitemIntIdx:
                record[lineitemHeader[i]] = int(lineVals[i])

                # sum up quantities
                if i == lineitemQuanityIdx:
                    quantitySum += record[lineitemHeader[i]]

            elif i <= lineitemFloatIdx:
                record[lineitemHeader[i]] = float(lineVals[i])
            else:
                record[lineitemHeader[i]] = lineVals[i]

        orderGroup.append(record)

    # yield final orderGroup
    if quantitySum > 300:
        for record in orderGroup:
            record["L_QUANITY_SUM"] = int(quantitySum)
            yield record

def q5_lineitem_order_load_local(inp, ins):
    fileNum = int(inp.split('_')[1].split('.')[0])
    orderFile = os.path.dirname(inp) + '/../order/order_' + str(fileNum) + '.csv'
    order = open(orderFile, 'r')

    # header
    orderHeader = order.readline()[:-1].split(delim)
    orderVals = order.readline()[:-1].split(delim)

    for i in xrange(len(orderHeader)):
        if orderHeader[i] == "O_ORDERDATE":
            orderDateIdx = i

    hasHeader = True
    lineitemHeader = None
    prevOrderNum = int(orderVals[0])

    orderGroup = []
    dateMin = "1994-01-01"
    dateMax = "1995-01-01"

    for line in ins:
        if hasHeader:
            lineitemHeader = line[:-1].split(delim)
            hasHeader = False

            for i in xrange(len(lineitemHeader)):
                if lineitemHeader[i] == "L_EXTENDEDPRICE":
                    lineitemExtendedPriceIdx = i
                elif lineitemHeader[i] == "L_DISCOUNT":
                    lineitemDiscountIdx = i

            continue

        record = {}
        lineVals = line[:-1].split(delim)

        orderNum = int(lineVals[0])

        if orderNum != prevOrderNum:
            if dateMin <= orderVals[orderDateIdx] and orderVals[orderDateIdx] < dateMax:
                for record in orderGroup:
                    yield record

            # start new order group
            orderVals = order.readline()[:-1].split(delim)
            prevOrderNum = orderNum

            orderGroup = []

        record["L_DISCOUNTPRICE"] = float(lineVals[lineitemExtendedPriceIdx]) * (1 - float(lineVals[lineitemDiscountIdx]))

        for i in xrange(len(lineitemHeader)):
            record[lineitemHeader[i]] = lineVals[i]

        for i in xrange(len(orderHeader)):
            record[orderHeader[i]] = orderVals[i]

        orderGroup.append(record)

    # yield final orderGroup
    if dateMin <= orderVals[orderDateIdx] and orderVals[orderDateIdx] < dateMax:
        for record in orderGroup:
            yield record

    order.close()

def q15_lineitem_load_local(inp, ins):
    hasHeader = True
    lineitemHeader = None

    dateMin = "1996-01-01"
    dateMax = "1996-04-01"

    for line in ins:
        if hasHeader:
            lineitemHeader = line[:-1].split(delim)
            hasHeader = False

            for i in xrange(len(lineitemHeader)):
                if lineitemHeader[i] == "L_SHIPDATE":
                    lineitemShipDateIdx = i
                if lineitemHeader[i] == "L_EXTENDEDPRICE":
                    lineitemExtendedPriceIdx = i
                elif lineitemHeader[i] == "L_DISCOUNT":
                    lineitemDiscountIdx = i

            continue

        record = {}
        lineVals = line[:-1].split(delim)

        if dateMin <= lineVals[lineitemShipDateIdx] and lineVals[lineitemShipDateIdx] < dateMax:
            record["L_DISCOUNTPRICE"] = float(lineVals[lineitemExtendedPriceIdx]) * (1 - float(lineVals[lineitemDiscountIdx]))

            for i in xrange(len(lineitemHeader)):
                record[lineitemHeader[i]] = lineVals[i]

            yield record

def q18_lineitem_order_load_local(inp, ins):
    fileNum = int(inp.split('_')[1].split('.')[0])
    orderFile = os.path.dirname(inp) + '/../order/order_' + str(fileNum) + '.csv'
    order = open(orderFile, 'r')

    # header
    orderHeader = order.readline()[:-1].split(delim)
    orderVals = order.readline()[:-1].split(delim)

    hasHeader = True
    lineitemHeader = None
    prevOrderNum = int(orderVals[0])

    orderGroup = []
    quantitySum = 0

    for line in ins:
        if hasHeader:
            lineitemHeader = line[:-1].split(delim)
            hasHeader = False
            continue

        record = {}
        lineVals = line[:-1].split(delim)

        orderNum = int(lineVals[0])

        if orderNum != prevOrderNum:
            # new order group, yield the previous group with quanity sums
            if quantitySum > 300:
                record = orderGroup[0]
                record["L_QUANITY_SUM"] = int(quantitySum)
                yield record

            # start new order group
            orderVals = order.readline()[:-1].split(delim)
            prevOrderNum = orderNum

            orderGroup = []
            quantitySum = 0

        for i in xrange(len(lineitemHeader)):
            record[lineitemHeader[i]] = lineVals[i]

            # sum up quantities
            if i == lineitemQuanityIdx:
                quantitySum += int(lineVals[i])

        for i in xrange(len(orderHeader)):
            record[orderHeader[i]] = orderVals[i]

        orderGroup.append(record)

    # yield final orderGroup
    if quantitySum > 300:
        record = orderGroup[0]
        record["L_QUANITY_SUM"] = int(quantitySum)
        yield record

    order.close()

timeIdx = 0
tickerIdx = 3
stockIdx = 6
numStocks = 8

def sim_load(inp, ins):
    hasHeader = True
    header = None
    delim = ','

    for line in ins:
        if hasHeader:
            header = line[:-1].split(delim)
            hasHeader = False
            continue

        record = {}
        lineVals = line[:-1].split(delim)

        for i in xrange(len(header) - 1):
            if i == timeIdx:
                record[header[i]] = int(lineVals[i])
            elif i <= 2:
                record[header[i]] = float(lineVals[i])
            else:
                record[header[i]] = lineVals[i]

        record["key"] = record["msecs"] * numStocks + int(lineVals[stockIdx])

        yield record
